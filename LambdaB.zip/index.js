const AWS = require("aws-sdk");
const s3 = new AWS.S3();
const mime = require("mimemessage");

exports.handler = async (event) => {
    let S3filename = event.Records[0].s3.object.key;
    console.log(JSON.stringify(event))
    S3filename = S3filename.replaceAll('+', ' ')
    S3filename = decodeURIComponent(S3filename)
    console.log(S3filename)
    var params = {
        Bucket: process.env.BUCKET,   //Reading data from Env variable BUCKET
        Key: S3filename
    };

    const s3File = await s3.getObject(params).promise();
    console.log(s3File);
    let buffer = s3File.Body;
    let fs = require("fs");
    let path = require("path");

    let ses = new AWS.SES();

    var mailContent = mime.factory({ contentType: "multipart/mixed", body: [] });

    mailContent.header("From", `Enter your from email address here`);
    //Create environment variable called DESTINATION, and change Environment Variable to the reciepents email.
    mailContent.header("To", `${process.env.DESTINATION}`);
    mailContent.header("Subject", "Missed Lex Utterances Report");

    var alternateEntity = mime.factory({
        contentType: "multipart/alternate",
        body: [],
    });

    var htmlEntity = mime.factory({
        contentType: "text/html;charset=utf-8",
        body:
            "   <html>  " +
            "   <head></head>  " +
            "   <body>  " +
            "   <h1>Hello!</h1>  " +
            "   <p>Please see the attached file for Missed Lex Utterances Reports.</p>  " +
            "   </body>  " +
            "  </html>  ",
    });
    var plainEntity = mime.factory({
        body: "Please see the attached file for Missed Lex Utterances Reports.",
    });

    alternateEntity.body.push(htmlEntity);
    alternateEntity.body.push(plainEntity);

    mailContent.body.push(alternateEntity);

    var data = fs.readFileSync(__dirname + "/customers.txt");
    var attachmentEntity = mime.factory({
        contentType: "text/csv",
        contentTransferEncoding: "base64",
        body: buffer.toString("base64").replace(/([^\0]{76})/g, "$1\n"),
    });
    attachmentEntity.header("Content-Disposition", `attachment ;filename="${S3filename}"`);

    mailContent.body.push(attachmentEntity);
    try {
        let results = await ses.sendRawEmail(
            {
                RawMessage: { Data: mailContent.toString() },
            }
        ).promise();

    } catch (e) {
        console.log(e)
    }

};
